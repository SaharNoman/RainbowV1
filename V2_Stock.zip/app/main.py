from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from app.database import SessionLocal
from app.models import Inventory
from app.notifier import send_low_stock_email
from apscheduler.schedulers.background import BackgroundScheduler
from datetime import datetime

app = FastAPI(title="Grocery Inventory API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ── Shared: fetch low stock items ────────────────────────
def fetch_low_stock(store=None):
    db = SessionLocal()
    query = db.query(Inventory)
    if store:
        query = query.filter(Inventory.store_name == store)
    items = query.all()
    db.close()

    alerts = [
        {
            "id": i.id,
            "item_name": i.item_name,
            "category": i.category,
            "store_name": i.store_name,
            "current_stock": i.current_stock,
            "threshold": i.threshold,
            "deficit": round(i.threshold - i.current_stock, 2),
        }
        for i in items
        if i.current_stock < i.threshold
    ]
    alerts.sort(key=lambda x: x["current_stock"])
    return alerts


# ── Scheduled job: runs every day at 8:00 PM ────────────
def scheduled_alert():
    print(f"[{datetime.now()}] Running scheduled low stock email...")
    low_items = fetch_low_stock()
    result = send_low_stock_email(low_items)
    print(f"[{datetime.now()}] Result: {result}")

scheduler = BackgroundScheduler()
scheduler.add_job(scheduled_alert, "cron", hour=20, minute=0)
scheduler.start()


# ── 1. Dashboard summary per store ──────────────────────
@app.get("/dashboard/stock-summary")
def stock_summary():
    db = SessionLocal()
    items = db.query(Inventory).all()
    db.close()

    summary = {}
    for i in items:
        store = i.store_name
        if store not in summary:
            summary[store] = {"total_items": 0, "low_stock_items": 0}
        summary[store]["total_items"] += 1
        if i.current_stock < i.threshold:
            summary[store]["low_stock_items"] += 1

    return summary


# ── 2. Full inventory list (optional store filter) ───────
@app.get("/inventory")
def get_inventory(store: str = Query(None)):
    db = SessionLocal()
    query = db.query(Inventory)
    if store:
        query = query.filter(Inventory.store_name == store)
    items = query.order_by(Inventory.category, Inventory.item_name).all()
    db.close()

    return [
        {
            "id": i.id,
            "item_name": i.item_name,
            "category": i.category,
            "store_name": i.store_name,
            "current_stock": i.current_stock,
            "threshold": i.threshold,
            "is_low": i.current_stock < i.threshold,
        }
        for i in items
    ]


# ── 3. Low stock alerts ──────────────────────────────────
@app.get("/low-stock")
def low_stock(store: str = Query(None)):
    return fetch_low_stock(store)


# ── 4. Update threshold ──────────────────────────────────
@app.put("/inventory/{item_id}/threshold")
def update_threshold(item_id: int, threshold: float = Query(...)):
    db = SessionLocal()
    item = db.query(Inventory).filter(Inventory.id == item_id).first()
    if not item:
        db.close()
        return {"error": "Item not found"}
    item.threshold = threshold
    db.commit()
    db.close()
    return {"message": "Threshold updated", "item_id": item_id, "new_threshold": threshold}


# ── 5. List all stores ───────────────────────────────────
@app.get("/stores")
def get_stores():
    db = SessionLocal()
    stores = db.query(Inventory.store_name).distinct().order_by(Inventory.store_name).all()
    db.close()
    return [s[0] for s in stores]


# ── 6. Health check ──────────────────────────────────────
@app.get("/health")
def health():
    db = SessionLocal()
    count = db.query(Inventory).count()
    db.close()
    return {"status": "ok", "total_records": count}


# ── 7. Manual: send alert email now ─────────────────────
@app.post("/notify/send-now")
def send_now(store: str = Query(None)):
    low_items = fetch_low_stock(store)
    result = send_low_stock_email(low_items)
    return result


# ── 8. Preview: what would be emailed ───────────────────
@app.get("/notify/preview")
def notify_preview(store: str = Query(None)):
    low_items = fetch_low_stock(store)
    return {
        "total_low_items": len(low_items),
        "stores_affected": list(set(i["store_name"] for i in low_items)),
        "items": low_items
    }
